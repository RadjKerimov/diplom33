-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost:8889
-- Время создания: Дек 14 2021 г., 16:40
-- Версия сервера: 5.7.32
-- Версия PHP: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `diplom3`
--

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(249) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tel` varchar(12) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Телефон',
  `password` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `surname` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Фамилия',
  `address` varchar(250) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Адрес',
  `works` varchar(250) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Места работы',
  `img` varchar(250) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Фото пользывателя',
  `status` tinyint(2) UNSIGNED DEFAULT NULL,
  `verified` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `resettable` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `roles_mask` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `registered` int(10) UNSIGNED NOT NULL,
  `last_login` int(10) UNSIGNED DEFAULT NULL,
  `force_logout` mediumint(7) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `email`, `tel`, `password`, `username`, `surname`, `address`, `works`, `img`, `status`, `verified`, `resettable`, `roles_mask`, `registered`, `last_login`, `force_logout`) VALUES
(3, 'user2@ya.ru', '+79282000000', '$2y$10$0gwVCC.VXDpVyDGu7N0SsOBBQid0zP9jFowokxQvBEZaAAbMFmf/y', 'Ильяс', 'Керимов', 'Краснодар ул.Заполярная 37', 'IT Director', 'avatar-iuser61b8a9e487e4f.jpg', 2, 1, 1, 8192, 1635105493, 1635972319, 19),
(4, 'user1@ya.ru', '79290000002', '$2y$10$0KnG.oTt/J/lCF379.bpaeixsnHg6gpmqPP6C3Je8w6FsALDisx7K', 'Лера', 'Керимов', 'Краснодар ул.Заполярная 37', 'Marlin Web', 'avatar-auser61b8887d26704.jpg', 1, 1, 1, 8192, 1635150817, 1638992425, 25),
(7, 'admin@ya.ru', '+79285554477', '$2y$10$Ks0awMWgRB.VskyWZIg4Y.FFTIzNcp1s4Eu9PXrANkul3fgaovtb6', 'Радик', 'Керимов', 'Краснодар ул.Заполярная 37/4', 'Marlin Веб-разработчик', 'avatar-admin-lguser61b89298e7cb2.jpg', 1, 1, 1, 1, 1636059227, 1639469893, 14);

-- --------------------------------------------------------

--
-- Структура таблицы `users_confirmations`
--

CREATE TABLE `users_confirmations` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `email` varchar(249) COLLATE utf8mb4_unicode_ci NOT NULL,
  `selector` varchar(16) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `token` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `expires` int(10) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users_confirmations`
--

INSERT INTO `users_confirmations` (`id`, `user_id`, `email`, `selector`, `token`, `expires`) VALUES
(1, 1, 'kerimovradj@ya.ru', 'CdZfE8SP4Bb5FQ3T', '$2y$10$Zt9zEteqGg.DBqeJQKhAmOHUD3j7bAUJc2BK8aHGJebY3.0O0A3/2', 1635188884),
(5, 4, '1111kerimovaleria@ya.ru', 'rskJ9TBRsH_qolua', '$2y$10$8OuFYKdJKZ4hrfzuzwAvQ.jTZOWUGtFAElQm5bv0CEkhv9QizZjoW', 1635309925),
(6, 3, '1111111kerimovradj@ya.ru', 'X-0onatpo0IZJyS4', '$2y$10$b9eJz8xfW/CqrmSD6p59BOcWkkfieqGC2ndEZj5z1HbxWhwnn4eb6', 1635489213);

-- --------------------------------------------------------

--
-- Структура таблицы `users_remembered`
--

CREATE TABLE `users_remembered` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user` int(10) UNSIGNED NOT NULL,
  `selector` varchar(24) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `token` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `expires` int(10) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `users_resets`
--

CREATE TABLE `users_resets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user` int(10) UNSIGNED NOT NULL,
  `selector` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `token` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `expires` int(10) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `users_throttling`
--

CREATE TABLE `users_throttling` (
  `bucket` varchar(44) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `tokens` float UNSIGNED NOT NULL,
  `replenished_at` int(10) UNSIGNED NOT NULL,
  `expires_at` int(10) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users_throttling`
--

INSERT INTO `users_throttling` (`bucket`, `tokens`, `replenished_at`, `expires_at`) VALUES
('ejWtPDKvxt-q7LZ3mFjzUoIWKJYzu47igC8Jd9mffFk', 74, 1639469893, 1640009893),
('CUeQSH1MUnRpuE3Wqv_fI3nADvMpK_cg6VpYK37vgIw', 4, 1636000059, 1636432059),
('sZYXdcyzJCIQjhLWDhxqtQgKYyGMgsFMjHNxwbpWOAE', 49, 1636059227, 1636131227),
('zb7GpCKGbyz8I1JYr34obWxu97hqdDki1SQnudLkDUM', 29, 1635105169, 1635177169),
('9duEiNl1Wo2JpvuQ026VrdWmBVm-q-ZkXAlHm98ejx4', 29, 1635105169, 1635177169),
('DVwyorKidvpG3_rBXvTYNezmxOEOIXemctDs3IimHOI', 29, 1635105494, 1635177494),
('QGzkjmLWN_D7VO-ls-cfInh_Ogz9NJo-oTFjRkB8fs4', 29, 1635105494, 1635177494),
('Jjl8HEbTSJpZBWoyXOajJXqciuUdngUbah061jwhliE', 19, 1636001002, 1636037002),
('WkxoC3ehZd2OI5L9fZO8KtXCNhQvSjOdGfx_xYxdbfk', 499, 1635977091, 1636149891),
('0sW_UpBTXnbn5ghEm759xQ7CeSB522CSEudy6sO_SXA', 29, 1635150817, 1635222817),
('lqUgxbrcv1fFDjjvHANPDAnVaWoOWFKn3nV_5YWLA1c', 29, 1635150817, 1635222817),
('XzoXXmdFdZhhytMupjY4rxG4XDuPxpsjWsedvVL6Mos', 0.00282407, 1635223769, 1635396569),
('XuJEDcv8ukwLqu1x6P90iBxBKvNDWdPR0Gu8IJfwp5U', 2, 1635402812, 1635921212),
('QUwZdm0emXZiO_nyE5RyyC9CmgvW-pzr_Nrlifrycxk', 0.538008, 1635449296, 1635622096),
('2X063fuVjbUg4UeSmRXAC530SCE_QUW5Djet1KqnKMg', 11, 1635448267, 1635477066),
('usJzlfOkgun63N0ED_jt3-lQBfCH4bewVX9uHtpARtQ', 29, 1635976742, 1636048742),
('0eCXlO7I5yTIsUzlquoLhcSzX7_QCvqhpqbiI56fS8U', 29, 1635976742, 1636048742),
('UCUG6boytJR9G5Z-6_ETMcRCORqQjkr-juIQpQUruWw', 499, 1636001002, 1636173802),
('bmrghKrIL5AvT8o_DqAPQqm0bE48VZ1xDM53aCJ-s_I', 29, 1636059227, 1636131227),
('dARwT-ZWNP3upY8Pc3Zx5sj3EppBXzrutRJnw02TUFs', 29, 1636059227, 1636131227);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Индексы таблицы `users_confirmations`
--
ALTER TABLE `users_confirmations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `selector` (`selector`),
  ADD KEY `email_expires` (`email`,`expires`),
  ADD KEY `user_id` (`user_id`);

--
-- Индексы таблицы `users_remembered`
--
ALTER TABLE `users_remembered`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `selector` (`selector`),
  ADD KEY `user` (`user`);

--
-- Индексы таблицы `users_resets`
--
ALTER TABLE `users_resets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `selector` (`selector`),
  ADD KEY `user_expires` (`user`,`expires`);

--
-- Индексы таблицы `users_throttling`
--
ALTER TABLE `users_throttling`
  ADD PRIMARY KEY (`bucket`),
  ADD KEY `expires_at` (`expires_at`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT для таблицы `users_confirmations`
--
ALTER TABLE `users_confirmations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `users_remembered`
--
ALTER TABLE `users_remembered`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT для таблицы `users_resets`
--
ALTER TABLE `users_resets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
